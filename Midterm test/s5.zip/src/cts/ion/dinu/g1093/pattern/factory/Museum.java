package cts.ion.dinu.g1093.pattern.factory;

public class Museum extends OnlineBooking{

	public Museum(String eventName, int price) {
		super(eventName, price);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

}
