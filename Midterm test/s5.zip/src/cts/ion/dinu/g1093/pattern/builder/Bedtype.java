package cts.ion.dinu.g1093.pattern.builder;

public enum Bedtype {
KING,
QUEEN,
SINGLE
}
