package cts.ion.dinu.g1093.pattern.factory;

public class TestFactory {

	public static void main(String[] args) {
		

	}

}
