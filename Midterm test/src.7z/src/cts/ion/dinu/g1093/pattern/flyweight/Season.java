package cts.ion.dinu.g1093.pattern.flyweight;

public enum Season {
SUMMER,
WINTER,
SPRING,
AUTUMN
}
