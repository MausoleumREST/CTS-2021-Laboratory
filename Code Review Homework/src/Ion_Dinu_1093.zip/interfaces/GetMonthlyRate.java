package interfaces;

public interface GetMonthlyRate {
	public double getMonthlyRate();
}
